<?php
    return [
        'en' => 'English',
        'ban' => 'Bangla',
    ];
